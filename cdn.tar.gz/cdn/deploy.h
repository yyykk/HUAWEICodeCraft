#ifndef __ROUTE_H__
#define __ROUTE_H__

#include "lib_io.h"
#include "lib_time.h"

void deploy_server(char * graph[MAX_EDGE_NUM], int edge_num, char * filename);

	

#endif
